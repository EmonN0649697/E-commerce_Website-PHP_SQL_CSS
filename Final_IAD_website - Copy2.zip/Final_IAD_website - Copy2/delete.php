<?php
include "includes/dbh.php";

$ID = $_GET["ID"];

$sql = "DELETE FROM product WHERE ID = '$ID'";

if(mysqli_query($conn, $sql))
{
	header("Location: adminpage.php");
}

else
{
	echo mysqli_error($conn);
}
?>