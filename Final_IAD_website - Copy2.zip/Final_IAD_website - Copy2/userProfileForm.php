<?php 
include "includes/dbh.php";

$ID=$_GET["user_usr"];

$sql = "SELECT * FROM users WHERE user_usr = '$ID'";

$result = mysqli_query($conn, $sql);

$row = mysqli_fetch_assoc($result);

?>

<!DOCTYPE html>
<html>
<head>
</head>

<body>

<form action = "updateUserTable.php" method = "post">
ID: <input type ="text" name = "user_id" value= <?php echo
$row["user_id"]; ?>><p>

First Name: <input type="text" name="user_first" value=<?php echo
$row["user_first"]; ?>><p>

Last Name: <input type="text" name="user_last" value=<?php echo
$row["user_last"]; ?>><p>

Email: <input type="email" name="user_email" value=<?php echo
$row["user_email"]; ?>><p>

Username: <input type="text" name="user_usr" value=<?php echo
$row["user_usr"]; ?>><p>

<input type = "submit">
</form>

</body>