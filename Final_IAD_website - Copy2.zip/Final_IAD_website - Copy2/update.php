<?php
include "includes/dbh.php";

if(isset($_POST["ID"])){
	$ID = $_POST["ID"];
}

if(isset($_POST["prodName"])){
	$prodName = $_POST["prodName"];
}
if(isset($_POST["prodPrice"])){
	$prodPrice = $_POST["prodPrice"];
}
if(isset($_POST["prodDes"])){
	$prodDes = $_POST["prodDes"];
}

$sql = "UPDATE product SET prodName='$prodName', prodPrice='$prodPrice', prodDes='$prodDes' WHERE ID = '$ID'";



if (mysqli_query($conn, $sql)){
	header("Location: adminpage.php");
}
else{
	echo mysqli_error($conn);
}?>