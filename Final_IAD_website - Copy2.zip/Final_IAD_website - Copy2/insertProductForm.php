<!DOCTYPE html>
<html>
<head>
</head>

<body>

<form action = "adminpage.php" method = "post">
Product Name: <input type ="text" name = "prodName" value= <?php echo
$row["prodName"]; ?>><p>

Price: <input type="int" name="prodPrice" value=<?php echo
$row["prodPrice"]; ?>><p>

Description: <input type="text" name="prodDes" value=<?php echo
$row["prodDes"]; ?>><p>

<input type = "submit">
</form>

</body>