<?php
include "includes/dbh.php";
session_start();

if(isset($_SESSION["user_usr"])){
	$user_usr = $_SESSION["user_usr"];
}

$sql = "SELECT * FROM product 
JOIN basket
ON product.ID = basket.prodID
WHERE user_usr = '$user_usr'";

$result= mysqli_query($conn, $sql);

while($row=mysqli_fetch_assoc($result))
{
	
	$prodID = $row["prodID"];
	$quantity = $row["quantity"];
	
	mysqli_query($conn, "INSERT INTO orderhistory
	(prodID, quantity, user_usr) VALUES
	('$prodID', '$quantity', '$user_usr')");
}

mysqli_query($conn, "DELETE FROM basket WHERE 
user_usr = '$user_usr'");


header("Location: profile.php");
?>