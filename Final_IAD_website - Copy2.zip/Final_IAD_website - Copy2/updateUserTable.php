<?php
include "includes/dbh.php";

if(isset($_POST["user_id"])){
	$user_id = $_POST["user_id"];
}

if(isset($_POST["user_first"])){
	$user_first = $_POST["user_first"];
}
if(isset($_POST["user_last"])){
	$user_last = $_POST["user_last"];
}
if(isset($_POST["user_email"])){
	$user_email = $_POST["user_email"];
	
if(isset($_POST["user_usr"])){
	$user_usr = $_POST["user_usr"];
}
}

$sql = "UPDATE users SET user_id='$user_id', user_first='$user_first', user_last='$user_last', user_email='$user_email', user_usr='$user_usr' WHERE user_id = '$user_id'";



if (mysqli_query($conn, $sql)){
	header("Location: adminpage.php");
}
else{
	echo mysqli_error($conn);
}?>