<?php
include "includes/dbh.php";

$ID = $_GET["ID"];

$sql = "SELECT * FROM product WHERE ID = '$ID'";
$result = mysqli_query($conn, $sql);

$row = mysqli_fetch_assoc($result);

header("Content-type:image/png" .$row["img"]);
echo $row["img"];
?>