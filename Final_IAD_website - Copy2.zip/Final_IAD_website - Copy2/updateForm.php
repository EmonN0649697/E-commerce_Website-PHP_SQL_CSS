<?php 
include "includes/dbh.php";

$ID=$_GET["ID"];

$sql = "SELECT * FROM product WHERE ID = '$ID'";

$result = mysqli_query($conn, $sql);

$row = mysqli_fetch_assoc($result);

?>

<!DOCTYPE html>
<html>
<head>
</head>

<body>

<form action = "update.php" method = "post">
ID: <input type ="text" name = "ID" value= <?php echo
$row["ID"]; ?>><p>

Product Name: <input type="text" name="prodName" value=<?php echo
$row["prodName"]; ?>><p>

Product Price: <input type="int" name="prodPrice" value=<?php echo
$row["prodPrice"]; ?>><p>

Product Description: <textarea name="prodDes" rows="4"
cols="30"><?php echo $row["prodDes"];?></textarea><p>

<input type = "submit">
</form>

</body>