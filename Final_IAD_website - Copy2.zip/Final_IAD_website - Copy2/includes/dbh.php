<?php

$host = "localhost";
$username = "n0649697";
$password = "12TmSjXY";
$db = "m_soft20171_n0649697";

$conn = mysqli_connect($host, $username, $password, $db);

?>