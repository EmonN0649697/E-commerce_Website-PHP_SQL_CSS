<?php

include_once 'dbh.php';
	
	

	if (isset($_POST["prodName"])){
		$prodName = $_POST["prodName"];
	}
	if (isset($_POST["prodPrice"])){
		$prodPrice = $_POST["prodPrice"];
	}
	if (isset($_POST["prodDes"])){
		$prodDes = $_POST["prodDes"];
	}
	
	$sql = "INSERT INTO product (prodName, prodPrice, prodDes) VALUES
	('$prodName', '$prodPrice', 'prodDes')";
	if (mysqli_query($conn, $sql)){
		header("Location: insertProductForm.php");
	}
	else{
		echo"Error:".mysqli_error($conn);
	}
	
	?>