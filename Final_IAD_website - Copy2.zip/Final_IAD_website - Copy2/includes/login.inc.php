<?php

session_start();

if (isset($_POST['submit'])){
	
	include'dbh.php';
	$usr = mysqli_real_escape_string($conn, $_POST['usr']);
	$pwd= mysqli_real_escape_string($conn, $_POST['pwd']);
	
	if(empty($usr) || empty($pwd)) {
		header("Location: ../homepage.php?login=empty");
		exit();
}else{
	$sql = "SELECT * FROM users WHERE user_usr='$usr'";
	$result = mysqli_query($conn, $sql);
	$resultCheck = mysqli_num_rows($result);
	if($resultCheck < 1) {
		//header("Location: ../homepage.php?login=error");
		exit();
	}else{
		if($row = mysqli_fetch_assoc($result)){
			//de-hashing password
			$hashedPwdCheck = password_verify($pwd, $row['user_pwd']);
			if($hashedPwdCheck == false){
				//header("Location: ../homepage.php?login=error");
				exit();
			}elseif ($hashedPwdCheck == true) {
				//lock in the user 
				$_SESSION['user_id'] = $row['user_id'];
				$_SESSION['user_first'] = $row['user_first'];
				$_SESSION['user_last'] = $row['user_last'];
				$_SESSION['user_email'] = $row['user_email'];
				$_SESSION['user_usr'] = $row['user_usr'];
				$_SESSION['level'] = $row['Level'];
				
			    if ($_SESSION['level'] == 'admin'){
					header("Location: ../adminpage.php?login=success");
					exit();
					}
				else{
					header("Location: ../profile.php?login=success");
				    exit();
				}
				
			}
			
		}			
	}
}
}else{
	//header("Location: ../login.php?login=error");
	exit();
}