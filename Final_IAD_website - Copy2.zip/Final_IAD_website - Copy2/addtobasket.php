<?php
session_start();

include "includes/dbh.php";

if(isset($_SESSION["user_usr"])){
	$user_usr = $_SESSION["user_usr"];
}

$ID = $_GET["ID"];

$sql = "SELECT * FROM basket WHERE prodID = '$ID' AND user_usr = '$user_usr'";

$result= mysqli_query($conn, $sql);

$count = mysqli_num_rows($result);

if($count > 0){
	mysqli_query($conn, "UPDATE basket SET quantity = quantity + 1 WHERE prodID='$ID' AND user_usr = '$user_usr'");
}

else{
	$insert = "INSERT INTO basket (prodID, user_usr) VALUES ($ID, '$user_usr')";
	mysqli_query($conn, $insert);
}

header("Location: viewBasket.php")


?>