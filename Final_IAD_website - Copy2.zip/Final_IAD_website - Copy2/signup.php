<!DOCTYPE html>
<html>
<head>
<meta charset="UTP-8">
<title>Sign Up</title>
<link rel="stylesheet" type="text/css" href="login.css">
</head>
<body>

<header>
	<nav>
		<div class="main-wrapper">
			<ul>
				<li><a href="Home.php">Home</a></li>
			</ul>
			<div class="nav-login">
				<form action="login.php" method="POST">
					<input type="text" name="usr" placeholder="username/e-mail">
					<input type="password" name="pwd" placeholder="Password">
					<button type="submit" name="submit">Login</button>
				</form>
				<a href ="signup.php">Sign Up</a>
				
			</div>
		</div>
	</nav>
</header>

<section class="main-container">
	<div class="main-wrapper">
		<h2>Sign Up</h2>
	</div>
		<form class="signup-form" action="includes/signup.inc.php" method="POST">
		<input type="text" name="first" placeholder="first name">
		<input type="text" name="last" placeholder="last name">
		<input type="text" name="email" placeholder="email">
		<input type="text" name="usr" placeholder="username">
		<input type="password" name="pwd" placeholder="password">
		<button type="Submit" name="submit">Sign Up</button>
		</form>
	</div>
</section>

