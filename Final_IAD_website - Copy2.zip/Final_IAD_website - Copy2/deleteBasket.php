<?php
include "includes/dbh.php";

$user_usr = $_GET["user_usr"];

$sql =  "DELETE FROM basket WHERE user_usr = '$user_usr";

if(mysqli_query($conn, $sql))
{
	header("Location: viewBasket.php");
}

else
{
	echo mysqli_error($conn);
}
?>