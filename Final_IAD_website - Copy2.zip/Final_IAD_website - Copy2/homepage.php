
<?php
session_start();



?>


<link href="contactUs.css" rel="stylesheet" type="text/css"/>
<html>
	<head>
	<link rel="stylesheet" href="https://www.w3schools.com/w3css/4/w3.css">
	<title>Phone Suits!</title>
	<meta http-equiv="X-UA-Compatible" content="ie=edge">
	<meta name="viewport" content="width=device-width, initial-scale=1">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
	<link href="home.css" rel="stylesheet" type="text/css"/>
	<link href="contactUs.css" rel="stylesheet" type="text/css"/>
	</head>
	
	
	<div class="icon-bar">
  <a href="#" class="facebook"><i class="fa fa-facebook"></i></a> 
  <a href="#" class="twitter"><i class="fa fa-twitter"></i></a> 
  <a href="#" class="google"><i class="fa fa-google"></i></a> 
  <a href="#" class="linkedin"><i class="fa fa-linkedin"></i></a>
  <a href="#" class="youtube"><i class="fa fa-youtube"></i></a> 
</div>

	<body>
		<div id="wrapper">
			
			<div id ="main_title">
				Phone Suits!
			</div>
			<div id="small_menu">
				<a href="profile.php">Profile</a> | 
				<a href="homepage.php">Home</a> | 
				<a href="Phones.php">Phones</a> | 
				<a href="viewBasket.php">Basket</a> |
				<a href="contactUs.php">Contact Us</a> | 
				
				<div class="nav-login">
					<form action = "includes/login.inc.php" method="POST">
						<input type="text" name="usr" placeholder="username">
						<input type="password" name="pwd" placeholder="Password">
						<button type="submit" name="submit">Login</button>
						
						
						
						
					</form>
					<a href ="thesignup.php">New User? .</a><br><br>
					
						logged on as: 
					<?php echo $_SESSION['user_usr'];?>
					
				</div>
			</div>
		</div>
			
			<div ="form"	
				<div class="w3-content w3-display-container">
  <img class="mySlides" src="images/phonecover1.jpg">
  <img class="mySlides" src="images/phonecover2.jpg">
  <img class="mySlides" src="images/phonecover3.jpg">
  <img class="mySlides" src="images/phonecover4.jpg">
  <img class="mySlides" src="images/phonecover5.jpg">
  <img class="mySlides" src="images/phonecover6.jpg">
  <img class="mySlides" src="images/phonecover7.jpg">
  <img class="mySlides" src="images/phonecover8.jpg">
  <img class="mySlides" src="images/phonecover9.jpg">
  <img class="mySlides" src="images/phonecover10.jpg">

  <button class="w3-button w3-black w3-display-left" onclick="plusDivs(-1)">&#10094;</button>
  <button class="w3-button w3-black w3-display-right" onclick="plusDivs(1)">&#10095;</button>
			</div>
			
			
		<div>	
						
				
			<div id="content">
					
					
					
			</div>
			
			<div id="footer">
			© Sohanur Rahman N0649697
			</div>
		</div>
		<script>
		
var slideIndex = 1;
showDivs(slideIndex);

function plusDivs(n) {
  showDivs(slideIndex += n);
}

function showDivs(n) {
  var i;
  var x = document.getElementsByClassName("mySlides");
  if (n > x.length) {slideIndex = 1}    
  if (n < 1) {slideIndex = x.length}
  for (i = 0; i < x.length; i++) {
     x[i].style.display = "none";  
  }
  x[slideIndex-1].style.display = "block";  
}

</script>
		
	</body>
</html>