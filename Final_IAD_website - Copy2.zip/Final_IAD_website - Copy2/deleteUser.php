<?php
include "includes/dbh.php";

$ID = $_GET["user_id"];

$sql = "DELETE FROM users WHERE user_id = '$ID'";

if(mysqli_query($conn, $sql))
{
	header("Location: userAdmin.php");
}

else
{
	echo mysqli_error($conn);
}
?>